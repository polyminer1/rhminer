#!/bin/sh
# solo mining on local wallet (main net)
./rhminer.exe -v 2 -r 20 -s http://127.0.0.1:4009 -cpu -cputhreads 2 -extrapayload TakeTheRedPill
