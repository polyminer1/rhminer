#!/bin/sh
# solomining on testnet local wallet
./rhminer.exe -v 2 -r 20 -s http://127.0.0.1:4109 -cpu -cputhreads 2 -extrapayload Test123



